# llmsearch

### Dev Setup
- `poetry install --no-root` - Contains packages which are installed when you run `pip install llmsearch`
- `poetry install --with dev --no-root -E pynvml -E beepy` - Dev setup